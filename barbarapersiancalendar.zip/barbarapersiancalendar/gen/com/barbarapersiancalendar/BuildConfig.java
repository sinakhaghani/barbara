/** Automatically generated file. DO NOT MODIFY */
package com.barbarapersiancalendar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}