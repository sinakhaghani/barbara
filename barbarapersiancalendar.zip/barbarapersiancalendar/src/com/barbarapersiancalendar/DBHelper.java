package com.barbarapersiancalendar;

import java.util.List;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.net.DhcpInfo;
import android.os.Build;
import android.os.Bundle;

public class DBHelper extends AbstractDate{

	public DBHelper(Context context) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String[] getMonthsList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getYear() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setYear(int year) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getMonth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setMonth(int month) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getMonthName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDayOfMonth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setDayOfMonth(int day) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getDayOfWeek() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDayOfYear() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getWeekOfYear() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getWeekOfMonth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void rollDay(int amount, boolean up) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rollMonth(int amount, boolean up) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rollYear(int amount, boolean up) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MainActivity> getEvent(Context context) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isLeapYear() {
		// TODO Auto-generated method stub
		return false;
	}

	public List<MainActivity> getDayEvent(PersianDate persianDate) {
		// TODO Auto-generated method stub
		return null;
	}

	public void closeDatabase() {
		// TODO Auto-generated method stub
		
	}
	
	
}
