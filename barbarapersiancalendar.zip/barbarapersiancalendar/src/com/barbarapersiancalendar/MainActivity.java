package com.barbarapersiancalendar;

import java.util.Calendar;

import com.barbarapersiancalendar.R;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	TextView[] date = new TextView[41];
	TextView txt_show_date_j ;
	TextView txt_show_date_gh ;
	TextView txt_show_date_mil ;
	TextView next;
	TextView prev;
	public int i;
	public int d;
	public int m;
	public int y;
	public int icon;
	public boolean check;
	public String txt_date;
	public int m_presentDay2;
	public int m_presentDay;
	public int m_presentMonth;
	public int presentMonth=0;
	public SharedPreferences pre ;
	public int m_presentYear;
	public int m_presentDay_gh;
	public int m_presentMonth_gh;
	public int m_presentYear_gh;
	public int m_presentDay_mil;
	public int m_presentMonth_mil;
	public int m_presentYear_mil;
	public String NameWeek;
	public String NameDate;
	public String NameMonth_gh;
	public String NameMonth_mil;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		TextView mounth = (TextView) findViewById(R.id.textViewMounth);
		next = (TextView) findViewById(R.id.next);
		prev = (TextView) findViewById(R.id.previous);

		date[0] = (TextView) findViewById(R.id.textView1);
		date[1] = (TextView) findViewById(R.id.textView2);
		date[2] = (TextView) findViewById(R.id.textView3);
		date[3] = (TextView) findViewById(R.id.textView4);
		date[4] = (TextView) findViewById(R.id.textView5);
		date[5] = (TextView) findViewById(R.id.textView6);
		date[6] = (TextView) findViewById(R.id.textView7);
		date[7] = (TextView) findViewById(R.id.textView8);
		date[8] = (TextView) findViewById(R.id.textView9);
		date[9] = (TextView) findViewById(R.id.textView10);
		date[10] = (TextView) findViewById(R.id.textView11);
		date[11] = (TextView) findViewById(R.id.textView12);
		date[12] = (TextView) findViewById(R.id.textView13);
		date[13] = (TextView) findViewById(R.id.textView14);
		date[14] = (TextView) findViewById(R.id.textView15);
		date[15] = (TextView) findViewById(R.id.textView16);
		date[16] = (TextView) findViewById(R.id.textView17);
		date[17] = (TextView) findViewById(R.id.textView18);
		date[18] = (TextView) findViewById(R.id.textView19);
		date[19] = (TextView) findViewById(R.id.textView20);
		date[20] = (TextView) findViewById(R.id.textView21);
		date[21] = (TextView) findViewById(R.id.textView22);
		date[22] = (TextView) findViewById(R.id.textView23);
		date[23] = (TextView) findViewById(R.id.textView24);
		date[24] = (TextView) findViewById(R.id.textView25);
		date[25] = (TextView) findViewById(R.id.textView26);
		date[26] = (TextView) findViewById(R.id.textView27);
		date[27] = (TextView) findViewById(R.id.textView28);
		date[28] = (TextView) findViewById(R.id.textView29);
		date[29] = (TextView) findViewById(R.id.textView30);
		date[30] = (TextView) findViewById(R.id.textView31);
		date[31] = (TextView) findViewById(R.id.textView32);
		date[32] = (TextView) findViewById(R.id.textView33);
		date[33] = (TextView) findViewById(R.id.textView34);
		date[34] = (TextView) findViewById(R.id.textView35);
		date[35] = (TextView) findViewById(R.id.textView36);
		date[36] = (TextView) findViewById(R.id.textView37);

		txt_show_date_j = (TextView) findViewById(R.id.text_show_date_j);
		txt_show_date_gh = (TextView) findViewById(R.id.text_show_date_gh);
		txt_show_date_mil = (TextView) findViewById(R.id.text_show_date_mil);



		// Get date from Function

		Calendar calendar = Calendar.getInstance();

		CivilDate civilDate = new CivilDate(calendar);
		CivilDate civilDate2 = new CivilDate(calendar);
		PersianDate persianDate = DateConverter.civilToPersian(civilDate);
		final PersianDate persianDate2 = DateConverter.civilToPersian(civilDate2);
		IslamicDate islamicDate = DateConverter.civilToIslamic(civilDate);

		m_presentDay2 = persianDate.getDayOfMonth();
		m_presentDay = persianDate.getDayOfMonth();
		m_presentMonth = persianDate.getMonth();
		m_presentYear = persianDate.getYear();

		m_presentDay_gh = islamicDate.getDayOfMonth();
		m_presentMonth_gh = islamicDate.getMonth();
		m_presentYear_gh = islamicDate.getYear();

		m_presentDay_mil = civilDate.getDayOfMonth();
		m_presentMonth_mil = civilDate.getMonth();
		m_presentYear_mil = civilDate.getYear();
		
		
		
		
		//Toast.makeText(MainActivity.this, m_presentDay + "/" + m_presentMonth + "/" + m_presentYear, Toast.LENGTH_LONG).show();
		persianDate2.setDate(m_presentYear, m_presentMonth, m_presentDay);
		civilDate2 = DateConverter.persianToCivil(persianDate2);
		int DayWeek = civilDate2.getMonth();

		switch(DayWeek)
		{
		case 1: NameDate="یکشنبه";break;
		case 2: NameDate="دوشنبه";break;
		case 3: NameDate="سه شنبه";break;
		case 4: NameDate="چهارشنبه";break;
		case 5: NameDate="پنجشنبه";break;
		case 6: NameDate="جمعه";break;
		case 7: NameDate="شنبه";break;

		}

		switch(m_presentMonth_gh)
		{
		case 1: NameMonth_gh="محرم";break;
		case 2: NameMonth_gh="صفر";break;
		case 3: NameMonth_gh="ربیع‌الاول";break;
		case 4: NameMonth_gh="ربیع‌الثانی";break;
		case 5: NameMonth_gh="جمادی‌الاول";break;
		case 6: NameMonth_gh="جمادی‌الثانی";break;
		case 7: NameMonth_gh="رجب";break;
		case 8: NameMonth_gh="شعبان";break;
		case 9: NameMonth_gh="رمضان";break;
		case 10: NameMonth_gh="شوال";break;
		case 11: NameMonth_gh="ذیقعده";break;
		case 12: NameMonth_gh="ذیحجه";break;
		}

		switch(m_presentMonth_mil)
		{
		case 1: NameMonth_mil="ژانویه";break;
		case 2: NameMonth_mil="فوریه";break;
		case 3: NameMonth_mil="مارس";break;
		case 4: NameMonth_mil="آوریل";break;
		case 5: NameMonth_mil="مه";break;
		case 6: NameMonth_mil="ژوئن";break;
		case 7: NameMonth_mil="ژوئیه";break;
		case 8: NameMonth_mil="اوت";break;
		case 9: NameMonth_mil="سپتامبر";break;
		case 10: NameMonth_mil="اکتبر";break;
		case 11: NameMonth_mil="نوامبر";break;
		case 12: NameMonth_mil="دسامبر";break;
		}



		date[6].setTextColor(Color.rgb(200,0,0));
		date[13].setTextColor(Color.rgb(200,0,0));
		date[20].setTextColor(Color.rgb(200,0,0));
		date[27].setTextColor(Color.rgb(200,0,0));
		date[34].setTextColor(Color.rgb(200,0,0));
		
		
		// to next months
		
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				presentMonth ++;
				pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = pre.edit();
				editor.putInt("value_months" , presentMonth);
				editor.commit();
				
				Intent refresh = new Intent(MainActivity.this, MainActivity.class);
				startActivity(refresh);//Start the same Activity
				finish();
				

			}

			
		});
		
		// previous months
		
		prev.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				presentMonth --;
				pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = pre.edit();
				editor.putInt("value_months" , presentMonth);
				editor.commit();
				
				Intent refresh = new Intent(MainActivity.this, MainActivity.class);
				startActivity(refresh);//Start the same Activity
				finish();

			}
		});
		
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		presentMonth = pre.getInt("value_months", 0);
		
		m_presentMonth = m_presentMonth + presentMonth;
		
		if(m_presentMonth == 13)
		{
			m_presentMonth=1;
			m_presentYear++;
		}
		if(m_presentMonth == 0)
		{
			m_presentMonth=12;
			m_presentYear--;
		} 
		
		persianDate.setDate(m_presentYear, m_presentMonth, 1);
		civilDate = DateConverter.persianToCivil(persianDate);
		int dayOfWeek = civilDate.getDayOfWeek();
		//Toast.makeText(MainActivity.this, m_presentMonth + "", Toast.LENGTH_LONG).show();
		
		
		

		// create date
		
		if(m_presentMonth<=6)
		{
			if(m_presentMonth==1)
				NameWeek="فروردین";
			if(m_presentMonth==2)
				NameWeek="اردیبهشت";
			if(m_presentMonth==3)
				NameWeek="خرداد";
			if(m_presentMonth==4)
				NameWeek="تیر";
			if(m_presentMonth==5)
				NameWeek="مرداد";
			if(m_presentMonth==6)
				NameWeek="شهریور";
			if(dayOfWeek==7)
			{
				for(i=0 ; i<31 ; i++)
				{
					
					date[i].setText(i+1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay-1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==6)
			{
				for(i=6 ; i<37 ; i++)
				{
					
					date[i].setText(i-5 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+5].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==5)
			{
				for(i=5 ; i<36 ; i++)
				{
					
					date[i].setText(i-4 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+4].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==4)
			{
				for(i=4 ; i<35 ; i++)
				{
					
					date[i].setText(i-3 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+3].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==3)
			{
				for(i=3 ; i<34 ; i++)
				{
					
					date[i].setText(i-2 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+2].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==2)
			{
				for(i=2 ; i<33 ; i++)
				{
					
					date[i].setText(i-1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==1)
			{
				for(i=1 ; i<32 ; i++)
				{
					
					date[i].setText(i + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			};
		}
		
		
		
		
		
		
		
		
		if(m_presentMonth>=7 && m_presentMonth<=11)
		{
			
			if(m_presentMonth==7)
				NameWeek="مهر";
			if(m_presentMonth==8)
				NameWeek="آبان";
			if(m_presentMonth==9)
				NameWeek="آذر";
			if(m_presentMonth==10)
				NameWeek="دی";
			if(m_presentMonth==11)
				NameWeek="بهمن";
			
			if(dayOfWeek==7)
			{
				for(i=0 ; i<30 ; i++)
				{
					
					date[i].setText(i+1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay-1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==6)
			{
				for(i=6 ; i<36 ; i++)
				{
					
					date[i].setText(i-5 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+5].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==5)
			{
				for(i=5 ; i<35 ; i++)
				{
					
					date[i].setText(i-4 + "");
				
				}
				if(presentMonth==0)
				date[m_presentDay+4].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==4)
			{
				for(i=4 ; i<34 ; i++)
				{
					
					date[i].setText(i-3 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+3].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==3)
			{
				for(i=3 ; i<33 ; i++)
				{
					
					date[i].setText(i-2 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+2].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==2)
			{
				for(i=2 ; i<32 ; i++)
				{
					
					date[i].setText(i-1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==1)
			{
				for(i=1 ; i<31 ; i++)
				{
					
					date[i].setText(i + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
		}
		
		
		
		
		
		
		if(m_presentMonth==12)
		{
			
			NameWeek="اسفند";
			if(dayOfWeek==7)
			{
				for(i=0 ; i<29 ; i++)
				{
					
					date[i].setText(i+1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay-1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==6)
			{
				for(i=6 ; i<35 ; i++)
				{
					
					date[i].setText(i-5 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+5].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==5)
			{
				for(i=5 ; i<34 ; i++)
				{
					
					date[i].setText(i-4 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+4].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==4)
			{
				for(i=4 ; i<33 ; i++)
				{
					
					date[i].setText(i-3 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+3].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==3)
			{
				for(i=3 ; i<32 ; i++)
				{
					
					date[i].setText(i-2 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+2].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==2)
			{
				for(i=2 ; i<31 ; i++)
				{
					
					date[i].setText(i-1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==1)
			{
				for(i=1 ; i<30 ; i++)
				{
					
					date[i].setText(i + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		if(m_presentMonth==12 && (m_presentYear==1395 || m_presentYear==1399)) // sale kabise
		{
			
			NameWeek="اسفند";
			if(dayOfWeek==7)
			{
				for(i=0 ; i<30 ; i++)
				{
					
					date[i].setText(i+1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay-1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==6)
			{
				for(i=6 ; i<36 ; i++)
				{
					
					date[i].setText(i-5 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+5].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}

			if(dayOfWeek==5)
			{
				for(i=5 ; i<35 ; i++)
				{
					
					date[i].setText(i-4 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+4].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==4)
			{
				for(i=4 ; i<34 ; i++)
				{
					
					date[i].setText(i-3 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+3].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==3)
			{
				for(i=3 ; i<33 ; i++)
				{
					
					date[i].setText(i-2 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+2].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==2)
			{
				for(i=2 ; i<32 ; i++)
				{
					
					date[i].setText(i-1 + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay+1].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
			if(dayOfWeek==1)
			{
				for(i=1 ; i<31 ; i++)
				{
					
					date[i].setText(i + "");
					
				}
				if(presentMonth==0)
				date[m_presentDay].setBackgroundDrawable(new ColorDrawable(Color.parseColor("#669900")));
			}
		}
		
		
		
		
		
		
		
		
	

		for(i=0 ; i<37 ; i++)
		{
			date[i].setTextSize(17);
		}

		if(presentMonth==0)
		{
			
			d = m_presentDay;
			pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
			SharedPreferences.Editor editor = pre.edit();
			editor.putInt("value_day" , d);
			editor.commit();
			
			m = m_presentMonth;
			pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
			SharedPreferences.Editor editor2 = pre.edit();
			editor2.putInt("value_moun" , m);
			editor2.commit();
			
			y = m_presentYear;
			pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
			SharedPreferences.Editor editor3 = pre.edit();
			editor3.putInt("value_year" , y);
			editor3.commit();
			
			
			txt_show_date_j.setText("امروز:" + "    " + NameDate  + " " + m_presentDay + " " + NameWeek + " " +  m_presentYear );
			txt_show_date_gh.setText("برابر با:" + "    " + m_presentDay_gh  + " " + NameMonth_gh + " " +  m_presentYear_gh );
			txt_show_date_mil.setText("و" + "  " + m_presentDay_mil  + " " + NameMonth_mil + " " +  m_presentYear_mil );
		}
		
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		d = pre.getInt("value_day", 0);
		
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		m = pre.getInt("value_moun", 0);
		
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		y = pre.getInt("value_year", 0);
		
		
		txt_date= y + "/" + m + "/" + d;
		
		// create Notification
		
		String ns = Context.NOTIFICATION_SERVICE;
		NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
		
		check = true;
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		check = pre.getBoolean("value_check_icon", false);
		if(check = true)
		{

		if(d==1)
			 icon = R.drawable.i1;
		if(d==2)
			 icon = R.drawable.i2;
		if(d==3)
			 icon = R.drawable.i3;
		if(d==4)
			 icon = R.drawable.i4;
		if(d==5)
			 icon = R.drawable.i5;
		if(d==6)
			 icon = R.drawable.i6;
		if(d==7)
			 icon = R.drawable.i7;
		if(d==8)
			 icon = R.drawable.i8;
		if(d==9)
			 icon = R.drawable.i9;
		if(d==10)
			 icon = R.drawable.i10;
		if(d==11)
			 icon = R.drawable.i11;
		if(d==12)
			 icon = R.drawable.i12;
		if(d==13)
			 icon = R.drawable.i13;
		if(d==14)
			 icon = R.drawable.i14;
		if(d==15)
			 icon = R.drawable.i15;
		if(d==16)
			 icon = R.drawable.i16;
		if(d==17)
			 icon = R.drawable.i17;
		if(d==18)
			 icon = R.drawable.i18;
		if(d==19)
			 icon = R.drawable.i19;
		if(d==20)
			 icon = R.drawable.i20;
		if(d==21)
			 icon = R.drawable.i21;
		if(d==22)
			 icon = R.drawable.i22;
		if(d==23)
			 icon = R.drawable.i23;
		if(d==24)
			 icon = R.drawable.i24;
		if(d==25)
			 icon = R.drawable.i25;
		if(d==26)
			 icon = R.drawable.i26;
		if(d==27)
			 icon = R.drawable.i27;
		if(d==28)
			 icon = R.drawable.i28;
		if(d==29)
			 icon = R.drawable.i29;
		if(d==30)
			 icon = R.drawable.i30;
		if(d==31)
			 icon = R.drawable.i31;

		CharSequence tickerText = d + ""; // ticker-text
		long when = System.currentTimeMillis();         
		Context context = getApplicationContext();     
		CharSequence contentTitle = "تقویم باربارا";  
		CharSequence contentText = txt_date;      
		Intent notificationIntent = new Intent(this, MainActivity.class);
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
		Notification notification = new Notification(icon, tickerText, when);
		notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);

		// and this
		final int HELLO_ID = 1;
		mNotificationManager.notify(HELLO_ID, notification);
		
		}
		else
		{
			
		}
		mounth.setText(NameWeek + "    " + m_presentYear);




	}
	
	protected void onDestroy() {
		super.onDestroy();
		presentMonth = 0;
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pre.edit();
		editor.putInt("value_months" , presentMonth);
		editor.commit();
		
	};
	
	
	protected void onResum(){
		super.onResume();
		check = false;
		pre = getSharedPreferences("barbara", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor2 = pre.edit();
		editor2.putBoolean("value_check_icon" , check);
		editor2.commit();
	}
}
